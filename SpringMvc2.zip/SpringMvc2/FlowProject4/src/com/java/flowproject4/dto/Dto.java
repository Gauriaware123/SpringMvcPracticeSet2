package com.java.flowproject4.dto;

public class Dto {
  private int fno;
  private int sno;
  private String primeResulte;
  private String evenOddResulte;
public String getEvenOddResulte() {
	return evenOddResulte;
}
public void setEvenOddResulte(String evenOddResulte) {
	this.evenOddResulte = evenOddResulte;
}
public int getFno() {
	return fno;
}
public void setFno(int fno) {
	this.fno = fno;
}
public int getSno() {
	return sno;
}
public void setSno(int sno) {
	this.sno = sno;
}
public String getprimeResulte() {
	return primeResulte;
}
public void setprimeResulte(String primeResulte) {
	this.primeResulte = primeResulte;
}
  
}
