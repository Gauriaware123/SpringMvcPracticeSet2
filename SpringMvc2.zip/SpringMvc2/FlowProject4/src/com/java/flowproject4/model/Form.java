package com.java.flowproject4.model;

public class Form {
  private int fno;
  private int sno;
  private String primeResulte;
  private String evenOddResulte;
  
public String getEvenOddResulte() {
	return evenOddResulte;
}
public void setEvenOddResulte(String evenOddResulte) {
	this.evenOddResulte = evenOddResulte;
}
public int getFno() {
	return fno;
}
public String getPrimeResulte() {
	return primeResulte;
}
public void setPrimeResulte(String primeResulte) {
	this.primeResulte = primeResulte;
}
public void setFno(int fno) {
	this.fno = fno;
}
public int getSno() {
	return sno;
}
public void setSno(int sno) {
	this.sno = sno;
}

  
}
