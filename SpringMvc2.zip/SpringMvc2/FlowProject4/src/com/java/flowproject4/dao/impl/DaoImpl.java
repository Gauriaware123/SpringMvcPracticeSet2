package com.java.flowproject4.dao.impl;

import org.springframework.jdbc.core.JdbcTemplate;

import com.java.flowproject4.dao.Dao;
import com.java.flowproject4.model.Form;

public class DaoImpl implements Dao{
     private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public void displayResulte(Form form) {
        System.out.println("dao is start");
		String query="insert into resultetable values("+form.getPrimeResulte()+" ,'"+form.getSno()+"')"; 
		jdbcTemplate.update(query);
        System.out.println("dao is end");

	}

}
