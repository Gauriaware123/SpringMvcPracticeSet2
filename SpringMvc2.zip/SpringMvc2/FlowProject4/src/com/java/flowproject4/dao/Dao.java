package com.java.flowproject4.dao;

import com.java.flowproject4.model.Form;

public interface Dao {
void displayResulte(Form form);
}
