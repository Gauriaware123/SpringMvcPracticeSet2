package com.java.flowproject4.service.impl;

import com.java.flowproject4.dao.Dao;
import com.java.flowproject4.dto.Dto;
import com.java.flowproject4.model.Form;
import com.java.flowproject4.service.Service;

public class ServiceImpl implements Service {
 private Dao dao;

	public void setDao(Dao dao) {
	this.dao = dao;
}
	@Override
	public void calculate(Dto dto)
	{
		
	  System.out.println("service is start");
	
      int fno=dto.getFno();	
      int sno=dto.getSno();
      String primeResulte="";
      String evenOddResulte="";
      
      boolean b = true;
	  for(int i=2;i<=3;i++) {
	  if(sno%i==0)
	  {
		  b=false;
		  primeResulte="sno is not prime";
		  System.out.println("sno is not prime");
		  break;
	  }
	  if(b)
	    {
		  primeResulte="sno is not prime";
		  System.out.println(sno + " is prime");
	    }
	  }
	  
      if(fno%2==0)
      {
    	 evenOddResulte ="even number";
    	 System.out.println("even number");
      }
       else {
    	   evenOddResulte ="odd number";
    	   System.out.println("odd number");
       }
    dto.setEvenOddResulte(evenOddResulte);
    dto.setprimeResulte(primeResulte);


    Form form = new Form();
    form.setSno(dto.getFno());
    form.setPrimeResulte(dto.getprimeResulte());
    form.setFno(dto.getFno());
    form.setEvenOddResulte(dto.getEvenOddResulte());
    dao.displayResulte(form);
    
	System.out.println("service is end");

	}

	}
