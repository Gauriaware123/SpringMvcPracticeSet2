package com.java.flowproject4.service;

import com.java.flowproject4.dto.Dto;

public interface Service {
 void calculate(Dto dto);
}
