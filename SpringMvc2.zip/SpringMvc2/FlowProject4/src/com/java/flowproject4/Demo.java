package com.java.flowproject4;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.java.flowproject4.controller.Controller;
import com.java.flowproject4.dto.Dto;

public class Demo {

	public static void main(String[] args) {
	 System.out.println("application is start");
     Resource resource = new ClassPathResource("applicationContext.Xml");
     BeanFactory beanfactory = new XmlBeanFactory(resource);
     Dto dto = new Dto();
     dto.setSno(10);
     dto.setFno(21);
     Controller c=(Controller)beanfactory.getBean("idController");
     c.doMathResulte(dto);
  	 System.out.println("application is end");
	}

}
