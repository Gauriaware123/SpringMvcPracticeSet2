package com.java.flowproject4.controller;

import com.java.flowproject4.dto.Dto;
import com.java.flowproject4.service.Service;

public class Controller {
 private Service service;

public void setService(Service service) {
	this.service = service;
}
 public void doMathResulte( Dto dto)
{
	System.out.println("controller start hear");
	service.calculate(dto);
	System.out.println("controller start hear");

}
 
}
