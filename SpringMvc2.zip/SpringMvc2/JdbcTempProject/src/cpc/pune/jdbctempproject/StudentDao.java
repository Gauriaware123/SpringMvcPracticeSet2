package cpc.pune.jdbctempproject;

import org.springframework.jdbc.core.JdbcTemplate;

public class StudentDao {

  private JdbcTemplate jdbcTemplate;

  public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
  int insertStud(Student student){
	  String query="Insert into student values(" + student.getSno() + ",'" + student.getSname() + "'," + student.getAge() + ")";
	  System.out.println("Record inserted succ");
	  return jdbcTemplate.update(query);
	  
  }

 

}
